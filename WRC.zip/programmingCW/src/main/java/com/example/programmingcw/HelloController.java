package com.example.programmingcw;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;

import java.io.*;
import java.net.URL;
import java.util.*;
import java.time.LocalDate;
import java.util.concurrent.ThreadLocalRandom;

public class HelloController implements Initializable {
    @FXML
    private Button homeBtn;

    @FXML
    private Pane homePane;

    @FXML
    private Button addBtn;

    @FXML
    private Pane addPane;

    @FXML
    private TextField addField1;

    @FXML
    private TextField addField2;

    @FXML
    private TextField addField3;

    @FXML
    private TextField addField4;

    @FXML
    private TextField addField5;

    @FXML
    private Button addButton1;

    @FXML
    private Button deleteBtn;

    @FXML
    private Pane deletePane;

    @FXML
    private TextField deleteField1;

    @FXML
    private Button updateBtn;

    @FXML
    private Pane updatePane;

    @FXML
    private TextField updateField1;

    @FXML
    private TextField updateField2;

    @FXML
    private TextField updateField3;

    @FXML
    private TextField updateField4;

    @FXML
    private TextField updateField5;

    @FXML
    private TextField updateField6;

    @FXML
    private Button viewBtn;

    @FXML
    private Pane viewPane;

    @FXML
    private TableView<Driver> viewTable;

    @FXML
    private TableColumn<Driver, String> viewDriver;

    @FXML
    private TableColumn<Driver, Integer> viewAge;

    @FXML
    private TableColumn<Driver, String> viewTeam;

    @FXML
    private TableColumn<Driver, String> viewCar;

    @FXML
    private TableColumn<Driver, Integer> viewPoints;

    @FXML
    private Button srrBtn;

    @FXML
    private Pane srrPane;

    @FXML
    private Label srrLabel1;

    @FXML
    private Label srrLabel2;

    @FXML
    private TableView<rallyRaces> srrTable;

    @FXML
    private TableColumn<rallyRaces, String> srrPosition;

    @FXML
    private TableColumn<rallyRaces, Integer> srrDriver;

    @FXML
    private TableColumn<rallyRaces, String> srrPoints;

    @FXML
    private Button sortBtn;

    @FXML
    private Pane sortPane;

    @FXML
    private Button saveBtn;

    @FXML
    private Pane savePane;

    @FXML
    private Button loadBtn;

    @FXML
    private Pane loadPane;


    private ObservableList<Driver> driverList = FXCollections.observableArrayList();
    private ObservableList<rallyRaces> races = FXCollections.observableArrayList();

    @FXML
    void Click(ActionEvent actionEvent) {

        if (actionEvent.getSource() == homeBtn) {
            homePane.toFront();
        }
        if (actionEvent.getSource() == addBtn) {
            addPane.toFront();
        }
        if (actionEvent.getSource() == deleteBtn) {
            deletePane.toFront();
        }
        if (actionEvent.getSource() == updateBtn) {
            updatePane.toFront();
        }
        if (actionEvent.getSource() == viewBtn) {
            viewPane.toFront();
        }
        if (actionEvent.getSource() == srrBtn) {
            srrPane.toFront();
        }
        if (actionEvent.getSource() == sortBtn) {
            sortPane.toFront();
        }
        if (actionEvent.getSource() == saveBtn) {
            savePane.toFront();
        }
        if (actionEvent.getSource() == loadBtn) {
            loadPane.toFront();
        }
    }

    @FXML
    //Method to add the driver details to the list
    private void addDetails(ActionEvent add) {
        Driver driver = null;
        String driverName = addField1.getText();
        int driverAge = 0;
        //Error handling done to make sure the driver's age is greater than 18
        try {
            driverAge = Integer.parseInt(addField2.getText());
            if (driverAge < 18) {
                throw new IllegalArgumentException("Invalid Input. The age must be greater than 18");
            }
            //Error handling done to make sure the driver's age is an integer. Error to show on popup message
        } catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Invalid Input. The age must be an Integer");
            alert.showAndWait();
            return;
        } catch (IllegalArgumentException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR, e.getMessage());
            alert.showAndWait();
            return;
        }

        String driverTeam = addField3.getText();
        String driverCar = addField4.getText();
        int driverCurrentPoints = 0;
        //Error handling done to make sure the driver's current points is an integer
        try {
            driverCurrentPoints = Integer.parseInt(addField5.getText());
        } catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Invalid Input. The points must be an Integer");
            alert.showAndWait();
            return;
        }
        //Error handling done to make sure all fields are filled
        if (driverName.isEmpty() || driverTeam.isEmpty() || driverCar.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Please fill all the fields");
            alert.showAndWait();
            return;
        }
        driver = new Driver(driverName, driverAge, driverTeam, driverCar, driverCurrentPoints);
        driverList.addAll(driver);
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Done");
        alert.setHeaderText(null);
        alert.setContentText("Entry Added Successfully!");
        alert.showAndWait();


        //Clearing the fields after the user enters details
        addField1.clear();
        addField2.clear();
        addField3.clear();
        addField4.clear();
        addField5.clear();
    }

    @FXML
    //Method to delete the driver details from the list
    public void deleteDetails(ActionEvent event) {
        String deleteName = deleteField1.getText();
        boolean driverExists = false;
        for (Driver driver : driverList) {
            if (driver.getDriverName().equals(deleteName)) {
                driverList.remove(driver);
                break;
            }else{
                Alert alert = new Alert(Alert.AlertType.ERROR, "Invalid Input. This driver does not exist");
                alert.showAndWait();
                return;
            }
        }

        //Clearing the field once the details are deleted
        deleteField1.clear();
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Done");
        alert.setHeaderText(null);
        alert.setContentText("Entry Deleted Successfully!");
        alert.showAndWait();

    }

    @FXML
    //Method to update driver details
    public void updateDetails(ActionEvent event) {
        //Getting the driver's current name
        String name = updateField1.getText();
        for (Driver driver : driverList) {
            //If that driver exists, then update the driver details with new entries
            String driverName = null;
            String driverTeam = null;
            String driverCar = null;
            if (driver.getDriverName().equals(name)) {
                driverList.remove(driver);
                driverName = updateField2.getText();
                int driverAge = Integer.parseInt(updateField3.getText());
                driverTeam = updateField4.getText();
                driverCar = updateField5.getText();
                int driverCurrentPoints = Integer.parseInt(updateField6.getText());
                driver = new Driver(driverName, driverAge, driverTeam, driverCar, driverCurrentPoints);
                driverList.addAll(driver);
                //Error message if driver does not exist
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Invalid Input. This driver does not exist");
                alert.showAndWait();
                return;
            }
        }
        //Clearing the fields once the details are updated
        updateField1.clear();
        updateField2.clear();
        updateField3.clear();
        updateField4.clear();
        updateField5.clear();
        updateField6.clear();
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Done");
        alert.setHeaderText(null);
        alert.setContentText("Entry Updated Successfully!");
        alert.showAndWait();
    }

    @FXML
    //Method to view the driver details
    public void viewStandings(ActionEvent event) {
        for (int i = 0; i < driverList.size() - 1; i++) {
            for (int j = 0; j < driverList.size() - i - 1; j++) {
                //Sorting the drivers records depending on the points
                if (driverList.get(j).getDriverCurrentPoints() < driverList.get(j + 1).getDriverCurrentPoints()) {
                    Driver temp = driverList.get(j);
                    driverList.set(j, driverList.get(j + 1));
                    driverList.set(j + 1, temp);
                }
            }
        }
        viewTable.setItems(driverList);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        viewDriver.setCellValueFactory(new PropertyValueFactory<Driver, String>("driverName"));
        viewAge.setCellValueFactory(new PropertyValueFactory<Driver, Integer>("driverAge"));
        viewTeam.setCellValueFactory(new PropertyValueFactory<Driver, String>("driverTeam"));
        viewCar.setCellValueFactory(new PropertyValueFactory<Driver, String>("driverCar"));
        viewPoints.setCellValueFactory(new PropertyValueFactory<Driver, Integer>("driverCurrentPoints"));
        viewTable.setItems(driverList);
        srrPosition.setCellValueFactory(new PropertyValueFactory<rallyRaces, String>("position"));
        srrDriver.setCellValueFactory(new PropertyValueFactory<rallyRaces, Integer>("name"));
        srrPoints.setCellValueFactory(new PropertyValueFactory<rallyRaces, String>("points"));
        srrTable.setItems(races);
    }

    public void simulateRandomRace(ActionEvent simulate) {
        //This is the code to simulate a random race between the drivers

        //Code to generate a randome date for the race
        LocalDate initialDay = LocalDate.now(); //start date
        long start = initialDay.toEpochDay();

        LocalDate lastDay = LocalDate.of(2024, 1, 1); //end date
        long end = lastDay.toEpochDay();

        long randomDate = ThreadLocalRandom.current().longs(start, end).findAny().getAsLong();
        LocalDate raceDate = LocalDate.ofEpochDay(randomDate);

        //Getting a random location for the race to run in from th below list
        List<String> raceLocations = new ArrayList<>();
        raceLocations.add("Nyirád");
        raceLocations.add("Höljes");
        raceLocations.add("Montalegre");
        raceLocations.add("Barcelona");
        raceLocations.add("Rīga");
        raceLocations.add("Norway");

        //Shuffling the locations in the list
        Collections.shuffle(raceLocations, new Random());
        //Getting a random date
        String raceLocation = raceLocations.get(new Random().nextInt(raceLocations.size()));

        List<Integer> pos = new ArrayList<>(driverList.size());
        for (int i = 1; i <= driverList.size(); i++) {
            pos.add(i);
        }

        List<Driver> sortedDriverList = new ArrayList<>();
        sortedDriverList.addAll(driverList);
        Collections.shuffle(sortedDriverList);

        //Printing the race date and the location in the given labels
        srrLabel1.setText("Location: " + raceLocation);
        srrLabel2.setText("Date: " + raceDate);

        try {
            FileWriter writer = new FileWriter("C:\\Programming Fundamentals - CW (Sem 2)\\programmingCW\\src\\main\\resources\\com\\example\\programmingcw\\rallyRaces.txt", true);
            for (int i = 0; i < sortedDriverList.size(); i++) {
                Driver driver = sortedDriverList.get(i);
                driver.setPosition(pos.get(i));
                //Assigning the points for the driver depending on the position
                switch (driver.getPosition()) {
                    case 1:
                        driver.setDriverCurrentPoints(sortedDriverList.get(i).getDriverCurrentPoints() + 10);
                        break;
                    case 2:
                        driver.setDriverCurrentPoints(sortedDriverList.get(i).getDriverCurrentPoints() + 7);
                        break;
                    case 3:
                        driver.setDriverCurrentPoints(sortedDriverList.get(i).getDriverCurrentPoints() + 5);
                        break;
                    case 4:
                        driver.setDriverCurrentPoints(sortedDriverList.get(i).getDriverCurrentPoints() + 0);
                        break;
                }

                String name = sortedDriverList.get(i).getDriverName();
                int position = sortedDriverList.get(i).getPosition();
                int point = sortedDriverList.get(i).getDriverCurrentPoints();
                rallyRaces racelist = new rallyRaces(name, raceDate, raceLocation, position, point);
                races.add(racelist);
            }
            System.out.println(Collections.unmodifiableList(races));
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        viewTable.refresh();
        File file = new File("C:\\Programming Fundamentals - CW (Sem 2)\\programmingCW\\src\\main\\resources\\com\\example\\programmingcw\\randomRaces.txt");
            try {
                //Writing data to file using the print writer.
                PrintWriter printWriter = new PrintWriter(new PrintWriter(file));
                for (rallyRaces races1:races) {
                    printWriter.write(races1.getName() + "," + races1.getDate() + "," + races1.getLocation() + "," + races1.getPosition() + "," + races1.getPoints() + "\n");
                }
                printWriter.close();
                System.out.println("Drivers data has been saved");

                //If there is an error, display the error message
            } catch (Exception e) {
                System.out.println("Error saving drivers data to file.");
            }
        }

    public void saveSRRFile(LocalDate date, String location, ObservableList<Driver> raceList) {
        if (raceList == null) {
            throw new IllegalArgumentException("List cannot be null");
        }

        try (FileWriter file = new FileWriter("SRR.txt", true)) {
            StringBuilder stringBuilder = new StringBuilder();
            for (Driver driverPositionPointsDetails : raceList) {
                String formatString = "| %-5s | %-15s | %-3s | %-20s | %-18s | %-6s | %-12s |\n";

                file.write(String.valueOf(driverPositionPointsDetails));
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void sortRacesByDate(ActionEvent actionEvent) {
        //Sorting the races according to date
        int n = races.size();
        for (int i = 0; i < n-1; i++) {
            for (int j = 0; j < n-i-1; j++) {
                LocalDate date1 = races.get(j).getDate();
                LocalDate date2 = races.get(j+1).getDate();
                if (date1.isAfter(date2)) {
                    // swap races at positions j and j+1
                    rallyRaces temp = races.get(j);
                    races.set(j, races.get(j+1));
                    races.set(j+1, temp);
                }
            }
        }
        File file = new File("C:\\Programming Fundamentals - CW (Sem 2)\\programmingCW\\src\\main\\resources\\com\\example\\programmingcw\\sortedRaces.txt");
        try {
            //Writing data to file using the print writer.
            PrintWriter printWriter = new PrintWriter(new PrintWriter(file));
            for (rallyRaces races1:races) {
                printWriter.write(races1.getName() + "," + races1.getDate() + "," + races1.getLocation() + "," + races1.getPosition() + "," + races1.getPoints() + "\n");
            }
            printWriter.close();
            System.out.println("Drivers data has been saved");

            //If there is an error, display the error message
        } catch (Exception e) {
            System.out.println("Error saving drivers data to file.");
        }
    }


    @FXML
    //Code to save data into a text file
    private void saveData(ActionEvent save) {
            //Creating a new FileWriter object that is used to write character streams to a file named Drivers.txt
            try {
                FileWriter writer = new FileWriter("C:\\Programming Fundamentals - CW (Sem 2)\\programmingCW\\src\\main\\resources\\com\\example\\programmingcw\\Drivers.txt");
                for (Driver driver : driverList) {
                    writer.write(driver.getDriverName() + "," + driver.getDriverAge() + "," + driver.getDriverTeam() + "," + driver.getDriverCar() + "," + driver.getDriverCurrentPoints()+ "\n");
                }

                writer.close();
                System.out.println("Success. Data has been saved successfully");
            } catch (IOException e) {
                System.out.println("Error! Unable to save the data " + e.getMessage());
            }
    }

    @FXML
    //Code to load data from a text file
    private void loadData(ActionEvent load) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader("C:\\Programming Fundamentals - CW (Sem 2)\\programmingCW\\src\\main\\resources\\com\\example\\programmingcw\\Drivers.txt"));
            String line;

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                String driverName = parts[0];
                int driverAge = Integer.parseInt(parts[1]);
                String driverTeam = parts[2];
                String driverCar = parts[3];
                int driverCurrentPoints = Integer.parseInt(parts[4]);

                Driver driver = new Driver(driverName, driverAge, driverTeam, driverCar, driverCurrentPoints);
                driverList.add(driver);
            }

            reader.close();
            System.out.println("Success. Data has been loaded successfully");
        } catch (IOException e) {
            System.out.println("Error! Unable to save the data " + e.getMessage());
        }
    }
}