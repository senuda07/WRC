package com.example.programmingcw;

public class Driver {
    private String driverName;
    private Integer driverAge;
    private String driverTeam;
    private String driverCar;
    private Integer driverCurrentPoints;

    private Integer position;
    public Driver(String driverName, Integer driverAge, String driverTeam, String driverCar, Integer driverCurrentPoints) {
        this.driverName = driverName;
        this.driverAge = driverAge;
        this.driverTeam = driverTeam;
        this.driverCar = driverCar;
        this.driverCurrentPoints = driverCurrentPoints;
    }

    public Driver() {

    }

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }

    public Integer getDriverAge() {
        return driverAge;
    }

    public void setDriverAge(Integer driverAge) {
        this.driverAge = driverAge;
    }

    public String getDriverTeam() {
        return driverTeam;
    }

    public void setDriverTeam(String driverTeam) {
        this.driverTeam = driverTeam;
    }

    public String getDriverCar() {
        return driverCar;
    }

    public void setDriverCar(String driverCar) {
        this.driverCar = driverCar;
    }

    public Integer getDriverCurrentPoints() {
        return driverCurrentPoints;
    }

    public void setDriverCurrentPoints(Integer driverCurrentPoints) {
        this.driverCurrentPoints = driverCurrentPoints;
    }

    public void setPosition(Integer position) {this.position = position;}

    public int getPosition() {return position;}

}
