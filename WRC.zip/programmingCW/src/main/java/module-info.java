module com.example.programmingcw {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.programmingcw to javafx.fxml;
    exports com.example.programmingcw;
}